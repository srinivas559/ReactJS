import React, {useState} from 'react';
const LoginForm= (props)=>{
    const [state,setState] =useState(
        {
        firstName: "",
        password: ""
    }
    )
    const handleChange = (event) =>{
        const {id, value} = event.target
        setState(prevState => ({
            ...prevState,
            [id] : value
        }))
        console.log([id] +":"+ value)        
    }
    const handleSubmit = (event)=>{
        event.preventDefault()
        console.log(state)
        if(state.firstName !== "" && state.password !== ""){
            props.history.push(`/userhome/${state.firstName}`)
        }
        else{
            alert("Please fill the details");
        }
    }
    return(
        <div className="container">
           
            <br /><br />
            <div className="row">
                <div className="col-12 d-flex justify-content-center">
                    <div className="jumbotron">
                        <h4>Login</h4>
                        <form onSubmit={handleSubmit}>
                            <div className="form-group">
                                <label htmlFor="firstName">First Name:</label>
                                <input id="firstName" value={state.firstName} type="text" className="form-control" onChange={handleChange}/>
                                <label htmlFor="password">Password:</label>
                                <input id="password" value={state.password} type="password" className="form-control" onChange={handleChange}/>  
                            </div>                        
                            <input type="Submit" className="form-control btn-success"/> 
                           
                        </form>
                    </div>
                </div>                
            </div>
            
        </div>
    );
 
}
 
export default LoginForm;