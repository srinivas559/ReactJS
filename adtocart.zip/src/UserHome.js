import React from 'react';
const UserHome = (props)=>{
    return(
        
        <>
            <h1>WELCOME to ur home Page {props.match.params.id} </h1>
            <a href="/LoginForm" className="btn btn-success" >Logout</a>
            
        </>
    )
}
 
export default UserHome;
