import React from 'react';
import {BrowserRouter as Router} from 'react-router-dom'
import './App.css';
import Header from './components2/Header'
import Section from './components2/Section'
import {DataProvider} from './components2/Context'

class App extends React.Component{
  render(){
    return(
      <DataProvider>
        <div className="app">
          <Router>
            <Header />
            <h1 className="mb-2">Welcome to Online Book store</h1>
            <Section />
          </Router>
        </div>
      </DataProvider>
    );
  }
}


export default App;
