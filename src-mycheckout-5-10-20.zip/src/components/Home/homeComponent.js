import React, { Component } from "react";
import { Switch, Route, Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import BooksList from "../Books/bookListComponent";


class Home extends Component {
    constructor(props) {
        super(props);

        this.state = {
            content: ""
        };
    }

    render() {
        return (
            <div>
                <nav className="navbar navbar-expand  ">

                    <div className="navbar-nav mr-auto">
                        <li className="nav-item">
                            <Link to={"/books"} className="nav-link">
                                All Category Books
                            </Link>
                        </li>
                    </div>
                </nav>

                <div className="container mt-3">
                    <Switch>
                        <Route path={["/"]} component={BooksList} />
                       
                    </Switch>
        </div>
            </div>
        );
    }
}

export default Home;