import React, { Component } from "react";
import { Switch, Route, Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";


import AuthService from "./services/auth.service";
import UserService from "./services/user.service";

import Login from "./components/Login/loginPageComponent";
import Register from "./components/Login/registerComponent";
import Home from "./components/Home/homeComponent";
import Profile from "./components/Login/profiledetailsComponent";
import BoardUser from "./components/User/userComponent";
import BoardAdmin from "./components/Admin/administratorComponnet";
import Cart from "./components/Cart/cartComponent";
import AddBook from "./components/Admin/addBookComponent";
import BooksList from "./components/Admin/booksEditComponent";
import Book from "./components/Admin/bookComponent";
import Checkout from "./components/Checkout/checkoutComponent";
import ThankYou from "./components/Checkout/thankyouComponent";
import ViewDetails from "./components/Checkout/viewDetailsComponent";
import BookList from "./components/Admin/booksEditComponent";
import CssBook from "./components/Books/css.component";
import HtmlBook from "./components/Books/html.component";
import Author from "./components/Admin/authorComponent";
//import Footer from "./components/Footer/footerComponent"
import Footer2 from "./components/Footer/Footer"

/*Icons */
import { GiShoppingCart } from "react-icons/gi";
import BooksEdit from "./components/Admin/booksEditComponent";
import { GiBookshelf } from "react-icons/gi";

class App extends Component {
    constructor(props) {
        super(props);
        this.logOut = this.logOut.bind(this);
        this.onChangeSearchTitle = this.onChangeSearchTitle.bind(this);
        this.searchTitle = this.searchTitle.bind(this);

        this.state = {
            books: [],
            showAdminBoard: false,
            currentUser: undefined,
            cart: [],
            searchTitle: ""
        };
    }



    componentDidMount() {
        const user = AuthService.getCurrentUser();

        if (user) {
            this.setState({
                currentUser: user,
                showModeratorBoard: user.roles.includes("ROLE_MODERATOR"),
                showAdminBoard: user.roles.includes("ROLE_ADMIN"),
            });
        }
    }

    onChangeSearchTitle(e) {
        const searchTitle = e.target.value;

        this.setState({
            searchTitle: searchTitle
        });
    }

    searchTitle() {
        UserService.findByTitle(this.state.searchTitle)
            .then(res => {
                this.setState({
                    books: res.data
                });
                console.log(res.data);
            })
            .catch(e => {
                console.log(e);
            });
    }

    logOut() {
        AuthService.logout();
    }

    render() {
        const { currentUser, showAdminBoard } = this.state;


        return (
            <div className="app">

                {/* <nav className="navbar navbar-expand navbar-light bg-light"> */}
                <nav className="navbar navbar-expand fixed-top" id="mainNav">

                    <Link to={"/"} className="navbar-brand">
                        <GiBookshelf />
                     Pro Books
                    </Link>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="collapsibleNavbar">
                        <div className="navbar-nav mr-auto">
                            <li className="nav-item">
                                <Link to={"/"} className="nav-link">
                                    Home
                            </Link>
                            </li>

                            {/* <li className="nav-item dropdown">
                                <Link className="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Category
                            </Link>

                                <div className="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                    <Link to={"/book"} class="dropdown-item" type="button">All Books</Link>
                                    <Link to={"/html"} class="dropdown-item" type="button">HTML</Link>
                                    <Link to={"/css"} class="dropdown-item" type="button">CSS</Link>
                                </div>

                            </li>

                            <li className="nav-item dropdown">
                                <Link className="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Author
                                </Link>
                                <div className="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                    <Link to={"/soumya"} class="dropdown-item" type="button">Soumya</Link>
                                </div>
                            </li> */}

                            <li className="nav-item dropdown">
                                <Link to="" className="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Category
                                </Link>
                                <div className="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                    <Link to={"/book"} class="dropdown-item" type="button">All Books</Link>
                                    <Link to={"/html"} class="dropdown-item" type="button">HTML</Link>
                                    <Link to={"/css"} class="dropdown-item" type="button">CSS</Link>
                                </div>
                            </li>

                            {showAdminBoard && (
                                <li className="nav-item">
                                    <Link to={"/books"} className="nav-link">
                                        Books
                                    </Link>
                                </li>
                            )}

                            {showAdminBoard && (
                                <li className="nav-item">
                                    <Link to={"/admin"} className="nav-link">
                                        Admin Board
                                </Link>
                                </li>
                            )}

                            {showAdminBoard && (
                                <li className="nav-item">
                                    <Link to={"/add"} className="nav-link">
                                        Add Books
                                    </Link>
                                </li>
                            )}





                            {currentUser && (
                                <li className="nav-item">
                                    <Link to={"/user"} className="nav-link">
                                        User
                                </Link>
                                </li>
                            )}



                            {/* <li className="nav-item">
                            <BooksEdit/>
                        </li> */}

                        </div>

                        {currentUser ? (
                            <div className="navbar-nav ml-auto">
                                <li className="nav-item">
                                    <Link to={"/profile"} className="nav-link">
                                        {currentUser.username}
                                    </Link>
                                </li>
                                <li className="nav-item">
                                    <a href="/login" className="nav-link" onClick={this.logOut}>
                                        LogOut
                                </a>
                                </li>

                                <li className="nav-item">
                                    {/* <span>{cart.length}</span> */}
                                    {/* <span>{cart.length}</span>  */}
                                    <Link to={"/cart"} className="nav-link">
                                        <GiShoppingCart style={{ fontSize: 32, color: "black" }} />
                                    </Link>
                                </li>


                            </div>
                        ) : (
                                <div className="navbar-nav ml-auto">
                                    <li className="nav-item">
                                        <Link to={"/login"} className="nav-link">
                                            Login
                                        </Link>
                                    </li>

                                    <li className="nav-item">
                                        <Link to={"/register"} className="nav-link">
                                            {/* <i class="fa fa-user-plus" aria-hidden="true" style={{ fontSize: 32, color: "blue" }}></i> */}
                                        Sign Up
                                        </Link>
                                    </li>

                                </div>
                            )}

                        {/* <div className="navbar-nav">
                        <li className="nav-item">
                            <span>{cart.length}</span> 
                            <Link to={"/cart"} className="nav-link">
                                Cart
                            </Link>
                        </li>


                    </div> */}

                    </div>
                </nav><br /><br /><br />

                <div className="container mt-3">
                    <Switch>
                        <Route exact path={["/", "/book"]} component={Home} />
                        <Route exact path="/book" component={BookList} />
                        <Route exact path="/books" component={BooksEdit} />
                        <Route exact path="/books/:id" component={Book} />
                        <Route exact path="/add" component={AddBook} />
                        <Route exact path="/login" component={Login} />
                        <Route exact path="/register" component={Register} />
                        <Route exact path="/profile" component={Profile} />
                        <Route path="/user" component={BoardUser} />
                        <Route path="/admin" component={BoardAdmin} />
                        <Route path="/cart" component={Cart} />
                        <Route path="/checkout" component={Checkout} />
                        <Route path="/thankyou" component={ThankYou} />
                        <Route path="/view/:id" component={ViewDetails} />
                        <Route path="/css" component={CssBook} />
                        <Route path="/html" component={HtmlBook} />
                        <Route path="/soumya" component={Author} />
                        {/* <Route path="/full" component={FullstackBooksList} /> */}
                    </Switch>
                </div>

                <br /><br /><br /><br /><br /><br />
                <Footer2 />

            </div>
        );
    }
}

export default App;