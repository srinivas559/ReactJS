import React, { Component } from "react";
import axios from 'axios';
import AuthService from "../../services/auth.service";


class BookList extends Component {
    constructor(props) {
        super(props);

        this.state = {
            books: [],
            cart: [],
            BookList: [],
            currentUser: AuthService.getCurrentUser(),
            searchValue: ''
        };

        this.addToCartHandler = this.addToCartHandler.bind(this);
        this.viewDetail = this.viewDetail.bind(this);
        this.goToLogin = this.goToLogin.bind(this);
        this.renderAllProducts = this.renderAllProducts.bind(this);
        // this.cart = this.cart.bind(this);
    }

    //New from old one

    addC() {
        console.log("Cart");
    }

    componentWillMount() {

        this.getAllBooks()

    }

    getAllBooks = () => {
        console.log("get books");
        axios.get("http://localhost:8080/api/books/g").then((res) => {
            this.setState({
                books: res.data
            });
            console.log(res.data);
        })
            .catch(e => {
                console.log(e);
            });

    }

    search = (word) => {
        // this.setState({ sortedProducts: this.state.products.sort((a, b) => { return a.stock - b.stock }) })
        if (word.target.value === "") {
            this.getAllBooks()
        }
        this.setState({ searchValue: word.target.value })
        let values = this.state.books.filter(e => {
            return (e.title.toLocaleLowerCase().includes(word.target.value.toLocaleLowerCase())) ||
                (e.category.toLocaleLowerCase().includes(word.target.value.toLocaleLowerCase())) ||
                (e.author.toLocaleLowerCase().includes(word.target.value.toLocaleLowerCase()))
        })
        this.setState({ BookList: values })
    }

    renderAllProducts = () => {
        const { currentUser } = this.state;
        if (this.state.searchValue !== "") {
            if (this.state.BookList.length === 0) {
                return (
                <h5>"Sorry ! No Such Book Found !"</h5>)
            }
            else {

                return this.state.BookList.map((book, index) => {
                    return (

                        <div className="col-lg-4">
                            <div className="card">
                                {/* <img class="card-img-top" src={Book2} alt="Card image" ></img> */}
                                <img src={`http://localhost:8080/${book.productImage}`} className="card-img-top" alt="..." />
                                <div className="card-body" key={index}>

                                    <p className="card-text "><strong>{book.title}</strong>&nbsp;</p>
                                    <p className="card-text"><strong>₹ {book.price}</strong>&nbsp;</p>
                                    <p className="card-text"><strong>{book.author}</strong>&nbsp;</p>


                                    {!currentUser ?
                                        <>
                                            <button className="btn btn-secondary" onClick={this.goToLogin} style={{borderRadius:15,border:"red"}}>Add to cart</button>&nbsp;&nbsp;
                                            <button className="btn btn-primary" onClick={() => this.viewDetail(book.id)} style={{borderRadius:15}}>View Details</button>
                                        </> : <>
                                            <button className="btn btn-secondary" onClick={() => this.addToCartHandler(book.id)} style={{borderRadius:15}}>Add to cart</button>&nbsp;&nbsp;
                                            <button className="btn btn-primary" onClick={() => this.viewDetail(book.id)} style={{borderRadius:15}}>View Details</button>
                                        </>

                                    }

                                    {/* <Link to="/cart" className="cart">Cart</Link> */}
                                </div>
                            </div>
                        </div>
                    );
                })

            }
        }
        else {
            return this.state.books.map((book, index) => {
                return (

                    <div className="col-lg-4 d-flex align-items-stretch">
                        <div className="card style={{width:400}}">
                            {/* <img class="card-img-top" src={Book2} alt="Card image" ></img> */}
                            <img src={`http://localhost:8080/${book.productImage}`} className="card-img-top" alt="..." />
                            <div className="card-body" key={index}>

                            <p className="card-text "><strong>{book.title}</strong>&nbsp;</p>
                                    <p className="card-text"><strong>₹ {book.price}</strong>&nbsp;</p>
                                    <p className="card-text"><strong>{book.author}</strong>&nbsp;</p>

                                {!currentUser ?
                                    <>
                                        <button className="btn btn-secondary" onClick={this.goToLogin} style={{borderRadius:15,border:"red"}}>Add to cart</button>&nbsp;&nbsp;
                                        <button className="btn btn-primary" onClick={() => this.viewDetail(book.id)} style={{borderRadius:15}}>View Details</button>&nbsp;
                                    </> : <>
                                        <button className="btn btn-secondary" onClick={() => this.addToCartHandler(book.id)} style={{borderRadius:15}}>Add to cart</button>&nbsp;&nbsp;
                                        <button className="btn btn-primary" onClick={() => this.viewDetail(book.id)} style={{borderRadius:15}}>View Details</button>&nbsp;
                                    </>

                                }


                            </div>
                        </div>
                    </div>
                );
            })


        }
    }


    addToCartHandler = (id) => {
        console.log(id);
        axios.post(
            `http://localhost:8080/cart/addBook?id=${id}&user=${this.state.currentUser.username}`
        ).then((res) => {
            console.log(this.state.currentUser.username);
            console.log(res.data.message);
            // if (this.state.currentUser.username === '') {
            //     this.props.history.push('/login');
            // }
            if (res.data.message === true) {
                this.props.history.push(`/cart`);
            } else {
                this.setState({
                    message: `Unable to add to cart please try again later`,
                });
                alert(this.state.message);
            }
        });
    };

    viewDetail = (id) => {
        console.log(id);
        this.props.history.push(`/view/${id}`);
    };

    goToLogin() {
        this.props.history.push('/login');
    }

    render() {
        console.log(this.state);
        return (
            
            
            
            <div className="container">
               <div className="input-group mb-3">
                        <input
                            type="text"
                            className="form-control search"
                            placeholder="Search by author,title and category"
                           
                            onChange={this.search}
                            
                        /></div>
                 &nbsp;
                <div className="row">

                    {this.renderAllProducts()}
                </div>
                <a id="back-to-top" href="#" class="btn btn-primary back-to-top" role="button">Move To Top</a>
              <script src="movetop.js"></script>

               
            </div>
          
        )
    }
}

export default BookList;