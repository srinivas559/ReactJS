import React, { Component } from "react";
import { Switch, Route } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import BookList from "../Books/bookListComponent";
import Carousel  from "react-bootstrap/Carousel"




export default class Home extends Component {
    constructor(props) {
        super(props);

        this.state = {
            content: ""
        };
        this.allBook = this.allBook.bind(this);
        this.allCss = this.allCss.bind(this);
        this.allHtml = this.allHtml.bind(this);
        this.authorSoumya = this.authorSoumya.bind(this);
    }

    allBook() {
        this.props.history.push("/book");
    }

    allCss() {
        this.props.history.push("/css");
    }

    allHtml() {
        this.props.history.push("/html");
    }

    authorSoumya() {
        this.props.history.push("/soumya");
    }

    render() {
        return (
            <div>
                <div id="marquee">
                    <marquee behavior="scroll" direction="left"><b>Welcome To ℙ𝕣𝕠 𝔹𝕠𝕠𝕜𝕤</b></marquee>
                </div>

                <Carousel>
                    <Carousel.Item>
                        <img
                            className="d-block w-100"
                            src="/images/Bookcarousel1.jpg"
                            alt="First slide"
                        />
                        
                    </Carousel.Item>
                    <Carousel.Item>
                        <img
                            className="d-block w-100"
                            src="/images/Bookcarousel2.jpg"
                            alt="Third slide"
                        />

                       
                    </Carousel.Item>
                   
                </Carousel>


                <div className="container mt-3">
                    <Switch>
                        <Route path={["/"]} component={BookList} />

                    </Switch>
                </div>

                <Carousel>
                    <Carousel.Item>
                        <img
                            className="d-block w-100"
                            src="/images/Bookcarousel1.jpg"
                            alt="First slide"
                        />
                        
                    </Carousel.Item>
                    <Carousel.Item>
                        <img
                            className="d-block w-100"
                            src="/images/Bookcarousel2.jpg"
                            alt="Third slide"
                        />

                       
                    </Carousel.Item>
                   
                </Carousel>


            </div>
        );
    }
}



