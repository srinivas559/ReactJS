import React from "react";
import { BiSmile } from 'react-icons/bi';

class ThankYou extends React.Component {

    render() {
        return (
            <div class="jumbotron" id="thankyou">
                <p>Thank you for Shopping with us</p>
                <p>Keep Shopping again <BiSmile style={{fontSize:30,color:"yellow"}}/></p>
            </div>
        );
    }
}
export default ThankYou;