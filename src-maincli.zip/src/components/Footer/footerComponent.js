import React, { Component } from "react";

/* Icons */
import {FaInstagram} from 'react-icons/fa';
import {FaFacebookF} from 'react-icons/fa';
import {FaWhatsapp} from 'react-icons/fa'; 
import {FaGithub} from 'react-icons/fa';

class Footer extends Component{
render(){
    return(
        <footer id="footer" className="col-sm-12">
                        <div className="container" >
                            <div id="terms">
                            <a href="#" style={{color:"black"}}>Privacy Policy</a>&nbsp;&nbsp;
                            <a href="#" style={{color:"black"}}>Terms of Use</a>&nbsp;&nbsp;
                            <a href="#" style={{color:"black"}}>About</a>&nbsp;
                            <hr/>
                            </div>
                            <div id="terms">
                              <a href="/" style={{color:"black"}}>www.probooks.com</a>
                            </div>
                        </div>
                       
                        <div class="row">
                            <div className="col-xs-6" id="icons">
                            <a href="www.facebook.com" style={{fontSize:30, color:"blue"}}><FaFacebookF/></a>&nbsp;
                            <a href="www.whatsappweb.com"  style={{fontSize:30,color:"green"}}><FaWhatsapp/></a>&nbsp;
                            <a href="www.instagram.com"  style={{fontSize:30,color:"pink"}}><FaInstagram/></a>&nbsp;
                            <a href="www.github.com"  style={{fontSize:30,color:"black"}}><FaGithub/></a>
                            </div>
                            <div className="col-xs-6" id="copy">
                               &copy;probooks
                            </div>
                        </div>
                    </footer>
    )
}
}

export default Footer;