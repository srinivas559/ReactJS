import React, { Component } from "react";
import { Switch, Route, Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";

import AuthService from "./services/auth.service";

import Login from "./components/loginPageComponent";
import Register from "./components/registerComponent";
import Home from "./components/Home/homeComponent";
import Profile from "./components/profiledetailsComponent";
import BoardUser from "./components/User/userComponent";
import BoardModerator from "./components/moderatorComponent";
import BoardAdmin from "./components/Admin/administratorComponnet";
import FullstackBooksList from "./components/Books/fullstackBooksComponent";
import AddBook from "./components/Books/addBookComponent";
import Cart from "./components/Cart/cartComponent";
import {DataContext} from './components/Cart/Context'
import Products from './components/Cart/section/Product'

import {DataProvider} from './components/Cart/Context'


class App extends Component {
    static contextType = DataContext;

    constructor(props) {
        super(props);
        this.logOut = this.logOut.bind(this);

        this.state = {
            showModeratorBoard: false,
            showAdminBoard: false,
            currentUser: undefined,
            cart: []
        };
    }



    componentDidMount() {
        const user = AuthService.getCurrentUser();
        
           if (user) {
            this.setState({
                currentUser: user,
                showModeratorBoard: user.roles.includes("ROLE_MODERATOR"),
                showAdminBoard: user.roles.includes("ROLE_ADMIN"),
            });
        }
    }

    logOut() {
        AuthService.logout();
    }

    render() {
        const { currentUser, showModeratorBoard, showAdminBoard } = this.state;
        

        return (
            <DataProvider>
            <div>
                {/* <nav className="navbar navbar-expand navbar-light bg-light"> */}
                <nav className="navbar navbar-expand " id="mainNav">
                    <Link to={"/"} className="navbar-brand">
                        Pro Books
                    </Link>
                    <div className="navbar-nav mr-auto">
                        <li className="nav-item">
                            <Link to={"/"} className="nav-link">
                                Home
                            </Link>
                        </li>
                        <li className="nav-item">
                            <Link to={"/full"} className="nav-link">
                                Full stack
                            </Link>
                        </li>
                        <li className="nav-item">
                            <Link to={"/add"} className="nav-link">
                                addBook
                            </Link>
                        </li>

                        {showModeratorBoard && (
                            <li className="nav-item">
                                <Link to={"/mod"} className="nav-link">
                                    Moderator Board
                                </Link>
                            </li>
                        )}

                        {showAdminBoard && (
                            <li className="nav-item">
                                <Link to={"/admin"} className="nav-link">
                                    Admin Board
                                </Link>
                            </li>
                        )}

                        {currentUser && (
                            <li className="nav-item">
                                <Link to={"/user"} className="nav-link">
                                    User
                                </Link>
                            </li>
                        )}
                    </div>

                    {currentUser ? (
                        <div className="navbar-nav ml-auto">
                            <li className="nav-item">
                                <Link to={"/profile"} className="nav-link">
                                    {/* {currentUser.username}*/}<i class="fa fa-user" aria-hidden="true" style={{fontSize:32,color:"orange"}}></i> 
                                </Link>
                            </li>
                            <li className="nav-item">
                                <a href="/login" className="nav-link" onClick={this.logOut}>
                                <i class="fa fa-sign-out" aria-hidden="true" aria-hidden="true" style={{fontSize:32,color:"blue"}}></i>
                </a>
                            </li>
                            <li className="nav-item">
                                    {/* <span>{cart.length}</span> */}
                                    <Link to={"/cart"} className="nav-link">
                                    <i class="fa fa-shopping-cart" aria-hidden="true" style={{fontSize:32,color:"green"}}></i>
                            </Link>
                                </li>
                        </div>
                    ) : (
                            <div className="navbar-nav ml-auto">
                                <li className="nav-item">
                                    <Link to={"/login"} className="nav-link">
                                    <i class="fa fa-sign-in" aria-hidden="true" style={{fontSize:32,color:"red"}}></i>
                                    </Link>
                                </li>

                                <li className="nav-item">
                                    <Link to={"/register"} className="nav-link">
                                    <i class="fa fa-user-plus" aria-hidden="true" style={{fontSize:32,color:"blue"}}></i>
                                    </Link>
                                </li>
                                <li className="nav-item">
                                    {/* <span>{cart.length}</span> */}
                                    <Link to={"/cart"} className="nav-link">
                                    <i class="fa fa-shopping-cart" aria-hidden="true" style={{fontSize:32,color:"green"}}></i>
                            </Link>
                                </li>
                            </div>
                        )}

                </nav>

                <div className="container mt-3">
                    <Switch>
                        <Route exact path="/" component={Products} />
                        <Route exact path="/product" component={Products} />
                        <Route exact path="/add" component={AddBook} />
                        <Route exact path="/login" component={Login} />
                        <Route exact path="/register" component={Register} />
                        <Route exact path="/profile" component={Profile} />
                        <Route path="/user" component={BoardUser} />
                        <Route path="/mod" component={BoardModerator} />
                        <Route path="/admin" component={BoardAdmin} />
                        <Route path="/cart" component={Cart} />
                        <Route path="/full" component={FullstackBooksList} />
                    </Switch>
                </div>
            </div>
            </DataProvider>
        );
    }
}

export default App;